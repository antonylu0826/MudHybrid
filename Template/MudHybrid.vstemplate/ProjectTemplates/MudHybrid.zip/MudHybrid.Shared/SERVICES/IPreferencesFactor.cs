﻿namespace $safeprojectname$.Services
{
    public interface IPreferencesFactor
    {
        public void Set(string key, string? value);
    }
}
